# DIGO — Solana Token Website

DIGO is a static React + TypeScript + Vite site for a community token on Solana Mainnet Beta. It uses the supplied DIGO dog mascot as the primary brand asset and keeps the public token facts explicit.

## Token facts

- **Token:** DIGO
- **Network:** Solana Mainnet Beta
- **Initial supply:** 100,000,000,000 DIGO
- **Decimals:** 8
- **Mint:** `7gqusyDEx6L7JNUfDEUftzdKRSejgzCUk7QCUwocYG1F`
- **Authority note:** mint authority has not been revoked, so the website does not describe supply as permanently fixed.

## Local development

Requires Node.js 20+ and pnpm 10. Install dependencies and start the Vite server:

```bash
pnpm install
pnpm dev
```

The development server listens on port 3000. Run a production check with:

```bash
pnpm lint
pnpm build
pnpm preview
```

## Environment configuration

Copy `.env.example` to `.env.local` only when you need to configure a public RPC endpoint or a verified public data provider. Values prefixed with `VITE_` are shipped to the browser, so never put private keys, seed phrases, credentials, or server secrets in them.

## Web3 safety boundary

The wallet layer uses maintained Solana wallet adapter packages and supports wallet connection state, address display, disconnect, and approval inside the wallet. The buy panel intentionally remains a clearly labeled frontend prototype until a verified pool, quote provider, and safe transaction route are configured. It does not show fake prices, fake liquidity, fake transaction confirmations, or simulated success states.

`src/lib/data/liveData.ts` contains the provider interface and an honest unavailable provider for price, liquidity, volume, market activity, and pool information. Replace it only with a verified API or on-chain data source and preserve loading, unavailable, and error states.

## Static deployment and GitHub

The production output is `dist/`. Any static host that can run `pnpm install --frozen-lockfile && pnpm build` and publish `dist/` can serve the site. For GitHub Pages, use a workflow or Pages build step with:

- Build command: `pnpm install --frozen-lockfile && pnpm build`
- Output directory: `dist`

When the site project is connected to GitHub through the Manus Webdev workflow, push the intended `main` commit through the managed GitHub connection. Do not add personal tokens to the repository. The `app.config.ts` file contains the public project-logo URL used by the project metadata hook.

## Structure

- `src/components/` — reusable navigation, wallet, data, and swap UI.
- `src/data/` — accurate token facts, roadmap, and FAQ copy.
- `src/lib/solana/` — wallet adapter configuration and address formatting.
- `src/lib/data/` — replaceable live-data provider contract.
- `public/assets/` — DIGO mascot and optimized icon.
- `public/manus-routes.json` — page route manifest for the home route.
