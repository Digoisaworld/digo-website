import { useEffect, useState } from 'react'
import { unavailableProvider, type LiveTokenData } from '../lib/data/liveData'

const initialState: LiveTokenData = {
  status: 'loading',
  sourceLabel: 'Connecting to a verified source',
  message: 'Checking for a trusted market-data provider…',
}

export function useLiveData(mintAddress: string) {
  const [data, setData] = useState<LiveTokenData>(initialState)

  useEffect(() => {
    let active = true
    setData(initialState)
    unavailableProvider.getTokenData(mintAddress)
      .then((nextData) => {
        if (active) setData(nextData)
      })
      .catch(() => {
        if (active) {
          setData({
            status: 'error',
            sourceLabel: 'Data source error',
            message: 'The verified data source could not be reached. No market figures are shown.',
          })
        }
      })
    return () => { active = false }
  }, [mintAddress])

  return data
}
