export const MINT_ADDRESS = '7gqusyDEx6L7JNUfDEUftzdKRSejgzCUk7QCUwocYG1F'

export const token = {
  name: 'DIGO',
  network: 'Solana Mainnet Beta',
  supply: '100,000,000,000 DIGO',
  decimals: '8',
  mint: MINT_ADDRESS,
  status: 'Mint authority not revoked',
}

export const roadmap = [
  {
    phase: '01',
    title: 'The first bark',
    text: 'Launch the core identity, publish the token facts, and give the community a clear place to gather.',
    state: 'live',
  },
  {
    phase: '02',
    title: 'Pack formation',
    text: 'Shape the community rituals, release the sticker language, and grow the open conversation around DIGO.',
    state: 'next',
  },
  {
    phase: '03',
    title: 'On-chain clarity',
    text: 'Connect verified market data and a safe swap route only when the underlying pool and quote can be validated.',
    state: 'planned',
  },
] as const

export const faqs = [
  {
    question: 'What is DIGO?',
    answer: 'DIGO is a community-first token concept on Solana Mainnet Beta, represented by a playful dog mascot and an intentionally clear, no-hype information layer.',
  },
  {
    question: 'Is the supply permanently fixed?',
    answer: 'No. The initial supply is 100,000,000,000 DIGO, but the mint authority has not yet been revoked. This site does not describe the supply as permanently fixed.',
  },
  {
    question: 'Can I buy DIGO here?',
    answer: 'The site includes a wallet-ready buy interface prototype. Live quotes and a swap transaction will only be enabled after a verified pool, quote source, and safe execution path are configured.',
  },
  {
    question: 'Do you ask for seed phrases?',
    answer: 'Never. A Solana wallet connection should be approved inside your wallet extension or app. DIGO will never ask for a seed phrase or private key.',
  },
]
