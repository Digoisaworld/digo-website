import React from 'react'
import ReactDOM from 'react-dom/client'
import { ConnectionProvider, WalletProvider } from '@solana/wallet-adapter-react'
import { clusterApiUrl } from '@solana/web3.js'
import App from './App'
import { walletAdapters } from './lib/solana/wallet'
import './styles/index.css'

const endpoint = import.meta.env.VITE_PUBLIC_RPC_URL || clusterApiUrl('mainnet-beta')

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ConnectionProvider endpoint={endpoint}>
      <WalletProvider wallets={walletAdapters} autoConnect={false}>
        <App />
      </WalletProvider>
    </ConnectionProvider>
  </React.StrictMode>,
)
