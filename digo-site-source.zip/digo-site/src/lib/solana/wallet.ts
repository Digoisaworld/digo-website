import { PhantomWalletAdapter } from '@solana/wallet-adapter-phantom'
import { SolflareWalletAdapter } from '@solana/wallet-adapter-solflare'
import type { WalletAdapter } from '@solana/wallet-adapter-base'
import { WalletAdapterNetwork } from '@solana/wallet-adapter-base'

export const network = WalletAdapterNetwork.Mainnet

export const walletAdapters: WalletAdapter[] = [
  new PhantomWalletAdapter(),
  new SolflareWalletAdapter({ network }),
]

export function shortenAddress(address: string, start = 4, end = 4) {
  if (address.length <= start + end + 3) return address
  return `${address.slice(0, start)}…${address.slice(-end)}`
}
