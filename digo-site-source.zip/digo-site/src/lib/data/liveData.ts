export type LiveDataStatus = 'loading' | 'ready' | 'unavailable' | 'error'

export type LiveTokenData = {
  priceUsd?: number
  liquidityUsd?: number
  volume24hUsd?: number
  marketActivity?: string
  pool?: string
  status: LiveDataStatus
  sourceLabel: string
  message: string
}

export interface LiveDataProvider {
  getTokenData(mintAddress: string): Promise<LiveTokenData>
}

/**
 * Deliberately returns an honest unavailable state until a verified API or on-chain
 * indexer is configured. It prevents fabricated price, liquidity, or volume numbers.
 */
export const unavailableProvider: LiveDataProvider = {
  async getTokenData() {
    return {
      status: 'unavailable',
      sourceLabel: 'Verified data source pending',
      message: 'Live market data will appear here once a reliable API or on-chain indexer is connected.',
    }
  },
}
