import { useState } from 'react'
import { ArrowDown, ChevronDown, CircleAlert, LockKeyhole, ShieldCheck } from 'lucide-react'
import { useWallet } from '@solana/wallet-adapter-react'
import { WalletButton } from './WalletButton'

export function SwapPanel() {
  const { connected } = useWallet()
  const [amount, setAmount] = useState('')

  return (
    <div className="swap-card">
      <div className="swap-card-topline">
        <div>
          <span className="eyebrow">BUY DIGO</span>
          <h3>Own the moment.</h3>
        </div>
        <div className="prototype-badge"><CircleAlert size={14} /> Prototype</div>
      </div>
      <p className="swap-note">A wallet-ready interface for the future verified route. No fake quotes, no simulated fills.</p>

      <div className="asset-field">
        <div className="field-label"><span>You send</span><span className="muted">Balance unavailable</span></div>
        <div className="asset-row">
          <input value={amount} onChange={(event) => setAmount(event.target.value.replace(/[^0-9.]/g, ''))} inputMode="decimal" placeholder="0.00" aria-label="SOL amount" />
          <button className="asset-select" aria-label="Select input asset"><span className="asset-icon sol-icon">S</span> SOL <ChevronDown size={15} /></button>
        </div>
      </div>
      <div className="swap-arrow"><ArrowDown size={17} /></div>
      <div className="asset-field output-field">
        <div className="field-label"><span>You receive</span><span className="muted">Estimate unavailable</span></div>
        <div className="asset-row">
          <div className="output-value">—</div>
          <div className="asset-select"><span className="asset-icon digo-icon">D</span> DIGO</div>
        </div>
      </div>

      <div className="swap-details">
        <div><span>Price impact</span><strong>Unavailable</strong></div>
        <div><span>Slippage</span><strong>Set on live route</strong></div>
        <div><span>Network fee</span><strong>Wallet quote required</strong></div>
      </div>

      {connected ? (
        <button className="button button-disabled full-button" disabled><LockKeyhole size={16} /> Live swap integration pending</button>
      ) : (
        <WalletButton />
      )}
      <div className="swap-safe-line"><ShieldCheck size={14} /> You approve every transaction inside your wallet.</div>
    </div>
  )
}
