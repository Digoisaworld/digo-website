import type { ReactNode } from 'react'

export function InfoCard({ label, value, detail, accent = 'lime' }: { label: string; value: string; detail: string; accent?: 'lime' | 'mint' | 'gold' }) {
  return (
    <div className={`info-card accent-${accent}`}>
      <span className="card-label">{label}</span>
      <strong>{value}</strong>
      <span className="card-detail">{detail}</span>
    </div>
  )
}

export function QuoteChip({ children, icon }: { children: ReactNode; icon?: ReactNode }) {
  return <span className="quote-chip">{icon}{children}</span>
}
