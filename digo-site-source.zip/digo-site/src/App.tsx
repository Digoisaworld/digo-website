import { useMemo, useState } from 'react'
import { ArrowDownRight, ArrowRight, ChevronDown, ChevronUp, Clipboard, ExternalLink, Github, Globe2, Menu, MessageCircle, MoveUpRight, ShieldCheck, Twitter, X } from 'lucide-react'
import { SectionLabel } from './components/SectionLabel'
import { InfoCard } from './components/InfoCard'
import { SwapPanel } from './components/SwapPanel'
import { WalletButton } from './components/WalletButton'
import { faqs, MINT_ADDRESS, roadmap, token } from './data/token'
import { useLiveData } from './hooks/useLiveData'
import { shortenAddress } from './lib/solana/wallet'

function App() {
  const [activeFaq, setActiveFaq] = useState(0)
  const [copied, setCopied] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const liveData = useLiveData(MINT_ADDRESS)

  const navigation = useMemo(() => [
    ['Token', '#token'],
    ['How to buy', '#buy'],
    ['Roadmap', '#roadmap'],
    ['FAQ', '#faq'],
  ], [])

  const copyMint = async () => {
    try {
      await navigator.clipboard.writeText(MINT_ADDRESS)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1600)
    } catch {
      setCopied(false)
    }
  }

  return (
    <div className="page-shell">
      <header className="container navbar">
        <a className="brand" href="#top" aria-label="DIGO home"><span className="brand-mark">D</span><span>DIGO</span></a>
        <nav className={`nav-links ${menuOpen ? 'nav-links-open' : ''}`} aria-label="Main navigation">
          {navigation.map(([label, href]) => <a key={href} href={href} onClick={() => setMenuOpen(false)}>{label}</a>)}
        </nav>
        <div className="nav-actions"><WalletButton compact /><button className="menu-button" aria-label={menuOpen ? 'Close menu' : 'Open menu'} onClick={() => setMenuOpen((value) => !value)}>{menuOpen ? <X size={18} /> : <Menu size={18} />}</button></div>
      </header>

      <main id="top">
        <section className="container hero" aria-labelledby="hero-title">
          <div className="hero-copy">
            <span className="eyebrow">Solana mainnet beta · community token</span>
            <h1 id="hero-title">Built for<br /><span>the pack.</span></h1>
            <p className="hero-lede">DIGO is a playful, transparent token identity on Solana. A big personality, a clear on-chain story, and a community that knows the difference between energy and empty hype.</p>
            <div className="hero-actions"><a className="button button-lime" href="#buy">Buy DIGO <ArrowDownRight size={16} /></a><a className="button button-outline" href="#token">Explore the facts <ArrowRight size={16} /></a></div>
            <div className="hero-proof"><strong>100B</strong><span>initial supply reference</span><i className="proof-line" /><strong>8</strong><span>decimals</span></div>
          </div>
          <div className="hero-art" aria-label="DIGO mascot artwork">
            <div className="hero-glow" /><div className="orbit one" /><div className="orbit two" />
            <img className="hero-mascot" src="assets/digo-mascot.png" alt="DIGO cartoon dog mascot" />
            <div className="hero-stamp"><strong>WOOF</strong>on<br />mainnet</div>
            <img className="hero-sticker" src="assets/stickers/sticker_01_rocket.png" alt="DIGO dog riding a rocket" />
          </div>
        </section>

        <div className="ticker" aria-label="DIGO status strip"><div className="container ticker-track"><span className="ticker-item"><b>01</b> transparent by design</span><span className="ticker-dot" /><span className="ticker-item">DIGO / SOL <b>—</b> live quote pending</span><span className="ticker-dot" /><span className="ticker-item">no fake numbers <b>✦</b> just the real story</span><span className="ticker-dot" /><span className="ticker-item">built for the pack <b>↗</b></span></div></div>

        <section className="container section token-section" id="token" aria-labelledby="token-title">
          <div className="section-top"><div><SectionLabel index="01">The token, clearly</SectionLabel><h2 className="section-title" id="token-title">Small dog.<br /><span>Big signal.</span></h2></div><p className="section-intro">The useful version of a token page starts with accurate facts. Market data stays unavailable until a verified source is connected.</p></div>
          <div className="metrics-grid"><InfoCard label="Network" value="Solana" detail="Mainnet Beta" accent="mint" /><InfoCard label="Initial supply" value="100B" detail="DIGO tokens" accent="lime" /><InfoCard label="Decimals" value="08" detail="Token precision" accent="gold" /><InfoCard label="Data status" value="Pending" detail="Verified source required" accent="mint" /></div>
          <div className="sticker-shelf" aria-label="DIGO community sticker gallery"><div className="sticker-shelf-copy"><span className="eyebrow">Sticker pack energy</span><strong>Same dog.<br /><span>More moods.</span></strong><p>Built for chat, timelines, and the whole pack.</p></div><figure className="sticker-tile sticker-hodl"><img src="assets/stickers/sticker_02_hodl.png" alt="DIGO dog holding a HODL sign" /><figcaption>HODL mode</figcaption></figure><figure className="sticker-tile sticker-dip"><img src="assets/stickers/sticker_03_buy_dip.png" alt="DIGO dog buying the dip" /><figcaption>Buy the dip</figcaption></figure><figure className="sticker-tile sticker-profit"><img src="assets/stickers/sticker_04_profit.png" alt="DIGO dog celebrating a profit" /><figcaption>Pack wins</figcaption></figure></div>
          <div className="token-split">
            <div className="token-facts">
              <div className="fact-row"><span>Token name</span><strong>{token.name}</strong></div>
              <div className="fact-row"><span>Network</span><strong>{token.network}</strong></div>
              <div className="fact-row"><span>Initial supply</span><strong>{token.supply}</strong></div>
              <div className="fact-row"><span>Mint address</span><strong>{shortenAddress(token.mint, 8, 8)} <button className="copy-button" onClick={copyMint} aria-label="Copy mint address"><Clipboard size={13} /> {copied ? 'Copied' : 'Copy'}</button></strong></div>
              <div className="fact-row"><span>Authority note</span><strong className="warning">Mint authority not revoked</strong></div>
            </div>
            <div className="live-panel"><div className="live-panel-header"><div><span className="eyebrow">Live snapshot</span><h3>Market data, without fiction.</h3></div><span className="live-status"><i className="status-dot" /> {liveData.status}</span></div><div className="live-empty"><div><div className="live-empty-icon"><Globe2 size={20} /></div><strong>{liveData.sourceLabel}</strong><p>{liveData.message}</p></div></div><div className="data-footnote">Data layer ready · provider interface is modular · no hardcoded prices</div></div>
          </div>
        </section>

        <section className="container section buy-section" id="buy" aria-labelledby="buy-title">
          <div className="section-top"><div><SectionLabel index="02">The route</SectionLabel><h2 className="section-title" id="buy-title">Buy with<br /><span>eyes open.</span></h2></div><p className="section-intro">A good swap flow tells you what it knows and what it does not. DIGO never asks for your seed phrase or private key.</p></div>
          <div className="buy-layout"><div className="buy-steps"><div className="buy-step"><span className="step-number">01</span><div><h3>Connect a Solana wallet</h3><p>Use Phantom or another supported wallet. Approve the connection inside your wallet, not inside a form on this page.</p></div></div><div className="buy-step"><span className="step-number">02</span><div><h3>Choose SOL → DIGO</h3><p>Enter an amount and review the live quote, price impact, slippage, and network fee once a verified route is available.</p></div></div><div className="buy-step"><span className="step-number">03</span><div><h3>Approve the transaction</h3><p>Review the transaction in your wallet. Nothing is signed automatically and no successful trade is claimed by this prototype.</p></div></div><div className="buy-sticker-note"><img src="assets/stickers/sticker_03_buy_dip.png" alt="DIGO dog pointing to buy the dip" /><span>Keep it playful.<br /><strong>Always verify the route.</strong></span></div></div><SwapPanel /></div>
        </section>

        <section className="container section" id="tokenomics" aria-labelledby="tokenomics-title">
          <div className="section-top"><div><SectionLabel index="03">Supply, not storytelling</SectionLabel><h2 className="section-title" id="tokenomics-title">One clear<br /><span>reference.</span></h2></div><p className="section-intro">The initial supply is known. Allocation percentages are not published here, so the chart shows a supply reference instead of invented categories.</p></div>
          <div className="tokenomics-grid"><div className="donut-wrap"><div className="donut"><div className="donut-center"><div><strong>100B</strong><span>initial DIGO</span></div></div></div></div><div className="legend"><div className="legend-row"><i className="legend-dot lime" /><span>Initial supply reference</span><strong>100%</strong></div><div className="legend-row"><i className="legend-dot mint" /><span>Allocation breakdown</span><strong>Not published</strong></div><div className="legend-row"><i className="legend-dot gold" /><span>Mint authority</span><strong>Active</strong></div><p className="section-intro">This is a visual reference for the known initial supply—not a claim about future supply policy or allocations.</p></div></div>
        </section>

        <section className="solana-band" id="ecosystem" aria-labelledby="ecosystem-title"><div className="container solana-layout"><div className="solana-copy"><SectionLabel index="04">Why Solana</SectionLabel><h2 className="section-title" id="ecosystem-title">Fast lanes.<br /><span>Open skies.</span></h2><p>DIGO lives in the Solana ecosystem: quick confirmations, deep developer momentum, and a culture that lets community identities move at internet speed. The project claims no partnership or listing—just a clear home.</p><a className="button button-outline" href="https://solana.com" target="_blank" rel="noreferrer">Explore Solana <ExternalLink size={15} /></a></div><div className="solana-badge" aria-hidden="true"><div className="solana-glyph"><i /><i /><i /></div></div></div></section>

        <section className="container section" id="roadmap" aria-labelledby="roadmap-title"><SectionLabel index="05">The path ahead</SectionLabel><h2 className="section-title" id="roadmap-title">No grand promises.<br /><span>Just good steps.</span></h2><div className="roadmap-grid">{roadmap.map((item) => <article className={`roadmap-card ${item.state === 'live' ? 'live' : ''}`} key={item.phase}><span className="roadmap-phase">{item.phase}</span><span className="roadmap-state">{item.state}</span><h3>{item.title}</h3><p>{item.text}</p></article>)}<div className="roadmap-sticker"><img src="assets/stickers/sticker_05_bear_market.png" alt="DIGO dog staying calm in a bear market" /><span>Even on red days,<br /><strong>the pack stays calm.</strong></span></div></div></section>

        <section className="container section" id="community" aria-labelledby="community-title"><div className="community"><div className="community-copy"><SectionLabel index="06">The pack</SectionLabel><h2 className="section-title" id="community-title">Bring your<br /><span>best bark.</span></h2><p>DIGO is designed to be shared, remixed, and understood. Community channels will be linked here when official handles are ready—no placeholder accounts, no invented announcements.</p><div className="hero-actions"><a className="button button-lime" href="#faq">Read the FAQ <ArrowRight size={15} /></a></div></div><div className="community-art"><img src="assets/stickers/sticker_04_profit.png" alt="DIGO dog celebrating with a trophy" /><div className="social-grid"><a className="social-link" href="#community"><span><Twitter size={17} /><br />X / handle pending</span><MoveUpRight size={16} /></a><a className="social-link" href="#community"><span><MessageCircle size={17} /><br />Telegram / pending</span><MoveUpRight size={16} /></a><a className="social-link" href="https://github.com" target="_blank" rel="noreferrer"><span><Github size={17} /><br />Source / GitHub</span><ExternalLink size={16} /></a><a className="social-link" href="#token"><span><ShieldCheck size={17} /><br />Facts first</span><ArrowRight size={16} /></a></div></div></div></section>

        <section className="container section" id="faq" aria-labelledby="faq-title"><div className="faq-grid"><div><SectionLabel index="07">Questions, answered</SectionLabel><h2 className="section-title" id="faq-title">Keep it<br /><span>simple.</span></h2><p className="section-intro">If an answer is not known yet, the answer says so. That is the point.</p></div><div className="faq-list">{faqs.map((faq, index) => <div className="faq-item" key={faq.question}><button className="faq-question" onClick={() => setActiveFaq(activeFaq === index ? -1 : index)} aria-expanded={activeFaq === index}>{faq.question}{activeFaq === index ? <ChevronUp size={17} /> : <ChevronDown size={17} />}</button>{activeFaq === index && <div className="faq-answer">{faq.answer}</div>}</div>)}</div></div></section>
      </main>

      <footer className="footer"><div className="container"><div className="footer-top"><div><a className="brand" href="#top"><span className="brand-mark">D</span><span>DIGO</span></a><p className="footer-copy">A playful token identity on Solana Mainnet Beta. Built for the pack, with the facts left in.</p></div><div className="footer-links"><a href="#token">Token</a><a href="#buy">Buy</a><a href="#roadmap">Roadmap</a><a href="#faq">FAQ</a></div></div><div className="footer-bottom"><span>© 2026 DIGO community project</span><span>Mint authority not revoked · no financial guarantees</span></div></div></footer>
    </div>
  )
}

export default App
